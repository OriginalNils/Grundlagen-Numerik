using Pkg

Pkg.activate(@__DIR__)
Pkg.instantiate()

#Pkg.add(["Plots"])

using LinearAlgebra
using PrettyTables
using LaTeXStrings
using Plots
######################################################################
#Helper functions for exercise 1
function  compute_1_norm(A)
    #we assume that A is quadratic matrix
    n = length(A[:,1])

    max = 0

    for j in 1:n
        sum_val = sum(abs.(A[:,j]))
        
        if sum_val > max
            max = sum_val
        end
    end
    return max
end

function compute_inf_norm(A)
    #we assume that A is quadratic matrix
    n = length(A[:,1])

    max = 0

    for i in 1:n
        sum_val = sum(abs.(A[i,:]))
        
        if sum_val > max
            max = sum_val
        end
    end
    return max
end


function compute_frobenius_norm(A)
    #we assume that A is quadratic matrix
    n = length(A[:,1])
    
    norm_val = 0
    
    for i in 1:n
        for j in 1:n
            norm_val += abs.(A[i,j])^2        
        end
    end
    norm_val = sqrt(norm_val)

    return norm_val
end

function create_Hilbert_matrix(n)
    #initialize a zero matrix
    H = zeros((n,n))

    for i in 1:n
        for j in 1:n
            H[i,j] = 1 / (i + j - 1)
        end
    end

    return H
end

#main function ex 1
function ex_1(;latex = false)
    ns = [10,20,30,40,50,60,70,80,90,100]

    norms_1 = []
    norms_infty = []
    norms_frobenius = []

    for n in ns
        H = create_Hilbert_matrix(n)
        push!(norms_1, compute_1_norm(H))
        push!(norms_infty, compute_inf_norm(H))
        push!(norms_frobenius, compute_frobenius_norm(H))
    end
    
    data = hcat(ns, norms_1, norms_infty, norms_frobenius)
    header = ["N", L"\|H\|_1", L"\|H\|_{\infty}", L"\|H\|_F"]
    kwargs = (; header)
    
    pretty_table(data; kwargs...)
    
    if latex
        pretty_table(data; kwargs..., backend=Val(:latex))
    end
    return nothing
end

#####################################################################
#Helper functions for exercise 2

function x_n(x_0, S, n)
    x_it = x_0
    
    for i in 1:n
        x_it = 0.5 * (x_it + S / x_it) 
    end

    return x_it
end

#main function ex2
function ex_2(;S = 0.5, x_0 = 1.0, latex = false)
    true_sol = sqrt(S)

    ns = [1,2,3,4,5,6,7,8,9,10,20,30,50]

    errors_x = []
    errors_y = []
    
    for n in ns
        x_num = x_n(x_0, S, n)

        push!(errors_x, abs(x_num - true_sol))
    end

    data = hcat(ns, errors_x)
    header = ["N", L"|\sqrt{S} - x_N|"]
    kwargs = (; header)
    
    pretty_table(data; kwargs...)

    if latex
        pretty_table(data; kwargs..., backend=Val(:latex))
    end
    return nothing
end

#####################################################################
#Helper functions for exercise 3
function create_grid(xmin, xmax, n)
    x = [xmin]
    dx = (xmax - xmin) / (n + 1)
    for i in 1:n + 1
        append!(x, xmin +  i * dx)
    end

    return x
end

function f(x)
    return x^2
end

function g(x)
    return exp(x)
end

function h(x)
    return sin(x)
end

function h_prime(x)
    return cos(x)
end

function create_D_forward(n)
    D = zeros(((n + 2), (n + 2)))
    h = 1 / (n + 1)
    #internal values
    for i in 2:n+1
        for j in 2:n+2
            if j == i + 1
                D[i,j] = 1
            end

            if j == i 
                D[i,j] = -1
            end
        end
    end
    #boundary values
    D[1,1] = 1
    D[end,end] = 1
    
    D = 1 / h * D

    return D
end

function create_D_backward(n)
    D = zeros(((n + 2), (n + 2)))
    h = 1 / (n + 1)
    #internal values
    for i in 2:n+1
        for j in 2:n+2
            if j == i - 1
                D[i,j] = -1
            end

            if j == i 
                D[i,j] = 1
            end
        end
    end
    #boundary values
    D[1,1] = 1
    D[end,end] = 1
    
    D = 1 / h * D

    return D
end
function create_D_central(n)
    D = zeros(((n + 2), (n + 2)))
    h = 1 / (n + 1)
    #internal values
    for i in 2:n+1
        for j in 2:n+2
            if j == i - 1
                D[i,j] = -1
            end

            if j == i + 1 
                D[i,j] = 1
            end
        end
    end

    #boundary values
    D[1,1] = 1
    D[end,end] = 1    
    
    D = 1 / (2h) * D

    return D
end

#main function ex 3
function ex_3(;xmin = 0.0, xmax = 1.0, n = 20)
    x_cl = create_grid(xmin, xmax, n)
    x_int = x_cl[2:end-1]
    
    D_p = create_D_forward(n)
    D_m = create_D_backward(n)
    D_0 = create_D_central(n)

    #plot the test of the derivative of the function f
    fig_f = scatter(x_int, (D_p * f.(x_cl))[2:end-1], marker = :cross, label = "Vorwärts", xlabel = L"x", ylabel = L"f^\prime(x)")
    scatter!(fig_f, x_int, (D_m * f.(x_cl))[2:end-1], marker = :cross, label = "Rückwärts")
    scatter!(fig_f, x_int, (D_0 * f.(x_cl))[2:end-1], marker = :cross, label = "Zentral")
    savefig(fig_f, "Plot_f.pdf")
    #plot the test of the derivative of the function g
    fig_g = scatter(x_int, (D_p * g.(x_cl))[2:end-1], marker = :cross, label = "Vorwärts", xlabel = L"x", ylabel = L"g^\prime(x)")
    scatter!(fig_g, x_int, (D_m * g.(x_cl))[2:end-1], marker = :cross, label = "Rückwärts")
    scatter!(fig_g, x_int, (D_0 * g.(x_cl))[2:end-1], marker = :cross, label = "Zentral")
    savefig(fig_g, "Plot_g.pdf")
    #convergence test
    ns = [10,50,30,70,80,100]
    error_p = []
    error_m = []
    error_0 = []

    for n in ns
        x_cl = create_grid(xmin, xmax, n)
        x_int = x_cl[2:end-1]

        D_p = create_D_forward(n)
        D_m = create_D_backward(n)
        D_0 = create_D_central(n)

        push!(error_p, max(abs.(h_prime.(x_cl) - D_p * h.(x_cl))...))
        push!(error_m, max(abs.(h_prime.(x_cl) - D_m * h.(x_cl))...))
        push!(error_0, max(abs.(h_prime.(x_cl) - D_0 * h.(x_cl))...))
    end
    fig_conv = scatter(ns, error_m, xaxis = :log, yaxis = :log, label = "vorwärts", xlabel = L"\log(N)", ylabel = L"\log(||Df - f^\prime||_{\infty})")
    scatter!(fig_conv, ns, error_p, xaxis = :log, yaxis = :log, marker = :cross, label = "rückwärts")
    scatter!(fig_conv, ns, error_0, xaxis = :log, yaxis = :log, marker = :cross, label = "zentral")
    savefig(fig_conv, "Konvergenzplot.pdf")

    return nothing
end