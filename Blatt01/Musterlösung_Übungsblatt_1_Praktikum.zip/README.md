1. Der Code wurde mit Hilfe von Julia 1.10.5 erstellt. Sie finden die Ergebnisse in der Datei `Musterlösung_Übungsblatt_1_Praktikum.pdf`

2. Um den Code auszuführen öffnen Sie im Verzeichnes der Datei `code.jl` eine Julia-REPL und führen Sie die Anweisung
```julia
    include("code.jl")
```
aus

3. Sie können dann auf die Funktionen
```julia
 ex_1()
 ex_2()
 ex_3()
```
zugreifen, welche die jeweiligen Aufgaben kodiert.